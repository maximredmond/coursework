# Read the cleaned data
df = pd.read_csv('cleaned_data.csv')

# Extract the data into lists
countries = list(df['Country'])
life_expectancy = list(df['Life Expectancy'])
gdp = list(df['GDP'])
doctors_per_capita = list(df['Doctors Per Capita'])
water_quality = list(df['Water Quality'])

# Get mean median and mode of each column
def mean_median_mode(column):
    mean = sum(column) / len(column)
    # If the length of the column is even, the median is the average of the two centre values
    # If the length of the column is odd, the median is the centre value
    if len(column) % 2 == 0:
        median = (sorted(column)[len(column) // 2] + sorted(column)[len(column) // 2 - 1]) / 2
    else:
        median = sorted(column)[len(column) / 2]
    # Get the mode by finding the most common value in the column
    mode = max(set([round(x) for x in column]), key=[round(x) for x in column].count)
    # Get the range of the column
    range_column = max(column) - min(column)
    return round(mean, 2), round(median, 2), round(mode, 2), round(range_column, 2) 

# Print the mean, median, mode, and range of each column except the mode of GDP as it is not meaningful
print("Life Expectancy:")
mean, median, mode, range_column = mean_median_mode(life_expectancy)
print(f"Mean: {mean}, Median: {median}, Mode: {mode}, Range: {range_column}")

print("GDP:")
mean, median, mode, range_column = mean_median_mode(gdp)
print(f"Mean: {mean}, Median: {median}, Range: {range_column}")

print("Doctors per Capita:")
mean, median, mode, range_column = mean_median_mode(doctors_per_capita)
print(f"Mean: {mean}, Median: {median}, Mode: {mode}, Range: {range_column}")

print("Water Quality:")
mean, median, mode, range_column = mean_median_mode(water_quality)
print(f"Mean: {mean}, Median: {median}, Mode: {mode}, Range: {range_column}")
