function validateForm() {
    // Get the GDP input element and its value
    var gdpInput = document.getElementById("gdp");
    var gdpValue = parseFloat(gdpInput.value);

    // Check if the GDP value is negative or not a number
    if (isNaN(gdpValue) || gdpValue < 0) {
        alert("Please enter a positive GDP value.");
        gdpInput.focus(); // Optional: set focus back to the GDP field for correction
        return false; // Prevent the form from being submitted
    }
    
    // If the value is valid, allow form submission
    return true;
}

fetch('form-data.csv') 

    .then(response => response.text()) 

    .then(data => { 

        let rows = data.split('\n').slice(1); // Remove header row 

        let table = document.getElementById('submissionsTable').getElementsByTagName('tbody')[0]; 

 

        rows.forEach(row => { 

            let cols = row.split(','); 

            if (cols.length === 4) { // Ensure row has the correct number of columns 

                let newRow = table.insertRow(); 

                cols.forEach(col => { 

                    let cell = newRow.insertCell(); 

                    cell.textContent = col; 

                }); 

            } 

        }); 

    }); 