function validateForm() {
    let x = document.forms["q-form"]["gdp"].value;
    if (x < 0) {
      alert("GDP must be a positive number");
      return false;
    }
  }

fetch('form-data.csv') 

    .then(response => response.text()) 

    .then(data => { 

        let rows = data.split('\n').slice(1); // Remove header row 

        let table = document.getElementById('submissionsTable').getElementsByTagName('tbody')[0]; 

 

        rows.forEach(row => { 

            let cols = row.split(','); 

            if (cols.length === 3) { // Ensure row has the correct number of columns 

                let newRow = table.insertRow(); 

                cols.forEach(col => { 

                    let cell = newRow.insertCell(); 

                    cell.textContent = col; 

                }); 

            } 

        }); 

    }); 