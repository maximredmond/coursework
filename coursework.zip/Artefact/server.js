const express = require('express'); 

const bodyParser = require('body-parser'); 

const createCsvWriter = require('csv-writer').createObjectCsvWriter; 

 

const app = express(); 

const port = 3000; 

app.use(bodyParser.urlencoded({ extended: false })); 

app.use(bodyParser.json()); 

const csvWriter = createCsvWriter({ 

    path: 'form-data.csv', 

    header: [ 

        {id: 'country', title: 'Country'}, 

        {id: 'gdp', title: 'GDP'}, 

        {id: 'clean_water', title: 'Access to clean water'}

    ], 

    append: true 

}); 

app.use(express.static('.')); 

app.post('/submit', (req, res) => { 

    const { country, gdp, clean_water } = req.body; 

    csvWriter.writeRecords([{ country, gdp, clean_water }]) 

        .then(() => { 

            res.redirect('/form.html'); 

        }); 

}); 

 
app.listen(port, () => { 

    console.log(`Server running at http://localhost:${port}/`); 

}); 